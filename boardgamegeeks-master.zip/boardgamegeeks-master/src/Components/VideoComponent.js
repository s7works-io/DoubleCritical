import React, { Component } from 'react';
import { View, Dimensions, Platform } from 'react-native';
import { Video } from 'expo-av';

const win = Dimensions.get('window');
const height = Dimensions.get('window').height;
const ratio = win.width/541;

export default class VideoComponent extends Component {
    constructor(props) {
        super(props);
    }

    render() {

        let URI = this.props.video_uri;

        return (

            <Video
                source={{ uri: this.props.video_uri }}
                isMuted={false}
                rate={1.0}
                resizeMode="contain"
                //shouldPlay
                isLooping
                style={{ width: Dimensions.get('window').width, height: height/3 }}
                useNativeControls={true}
            />
        );
    }
}

