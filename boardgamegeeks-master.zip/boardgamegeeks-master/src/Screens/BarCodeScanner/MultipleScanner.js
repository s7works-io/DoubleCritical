import { Text, View, TouchableOpacity, Platform, Alert, Dimensions, AsyncStorage } from "react-native";
import React from "react";
import styles from "../../Styles/BarCodeScannerStyles/ScanStyleSheet";
import { isbnVideoScanner, FetchIsbn } from "../../Networks/ISBNCalls";
import { _retrieveData } from "../../Networks/LoginScreenCalls";
import {
  discoveryMode,
  productLink,
  GameLike
} from "../../Networks/DiscoveryCalls";
import { Constants } from "expo-constants";
import * as Permissions from "expo-permissions";
import { BarCodeScanner } from "expo-barcode-scanner";
import {
  FontAwesome,
  AntDesign,
  EvilIcons,
  Ionicons
} from "@expo/vector-icons";
import Image from "react-native-remote-svg";
import { Container, Content, Input, Footer, FooterTab } from "native-base";
import { LinearGradient } from "expo-linear-gradient";
import { CustomTouchableIcon } from "../../Components/Header/CustomTouchableIcon";

export default class MultipleScanner extends React.Component {

  static navigationOptions = ({ navigation }) => {
    return {
      headerStyle: {
        height: Platform.OS === 'ios' ? 55 : 65,
              elevation: 0,
              shadowOpacity: 0,
              borderBottomWidth: 0,
          
      },
      headerLeft: (
        <View style={{ flexDirection: "row", alignItems: "center",marginLeft:8,marginRight:10 }}>
  
          <CustomTouchableIcon onPress={() => navigation.navigate("Scan")}>
            <Ionicons name="ios-arrow-back" size={25} color={"white"} />
          </CustomTouchableIcon>
  
          <Text
            style={{
              marginBottom: Platform.OS === 'ios' ? 6 : null,
              color: "#fff",
              fontWeight: "bold",
              fontSize: 18,
              marginLeft:5
            }}>
            MultipleScanGame
          </Text>
        </View>
      ),
      headerRight: (
        <View style={{marginRight:10}}>
          <CustomTouchableIcon
            onPress={() => {
              navigation.navigate("Search");
            }}
          >
            <EvilIcons name="search" size={28} color={"white"} />
          </CustomTouchableIcon>
        </View>
      ),
      headerBackground: (
        <LinearGradient
          colors={["#001a33", "#004f99"]}
          style={{ flex: 1 }}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
        />
      ),
      headerBackTitle: null,
      headerTintColor: "white",
     
    }
  }

  constructor(props) {
    super(props);

    this.state = {
      hasCameraPermission: null,
      game_id: "",
      user_id: "",
      productData: [],
      focusedScreen: false,
      scanCount:0,
      storedData: [],
    };
    this.FetchIsbn = this.FetchIsbn.bind(this);
    this.storeArray = this.storeArray.bind(this);
    this.AfterDeleteUpdate=this.AfterDeleteUpdate.bind(this);
    this.deleteParticularScannedGames = this.deleteParticularScannedGames.bind(this);
  }

  componentDidMount() {
    this._requestCameraPermission();
  }

  _requestCameraPermission = async () => {
    const { status } = await Permissions.askAsync(Permissions.CAMERA);
    this.setState({
      hasCameraPermission: status === "granted"
    });
  };

  _handleBarCodeRead = data => {
    Alert.alert("Scan successful!", JSON.stringify(data));
  };

  storeArray(gameData) {
    let storedData = this.state.storedData
    if(storedData && storedData.length == 0 || !storedData.find(data => data.id == gameData.id)) {
      storedData.push(gameData)
      this.setState({storedData: storedData})
    }

    //Store the scanned game data in asyncstorage for scanhistory
    this.storeDataAsyncStorage(gameData) 
  }

  async storeDataAsyncStorage(gameData) {
    let storedData;
    try {
      storedData = JSON.parse(await AsyncStorage.getItem('ScanHistoryJS'))
    } catch(error) {
      console.log('[Scan] Storage Error In MultipleScanner')
    }

    if(!storedData) {
      await AsyncStorage.setItem('ScanHistoryJS', JSON.stringify([gameData]))
    } else if(!storedData.find(data => data.id == gameData.id)) {
      storedData.push(gameData)
      return await AsyncStorage.setItem('ScanHistoryJS', JSON.stringify(storedData));
    }
  }

  AfterDeleteUpdate(storedData_afterDelete){
    this.setState({storedData:storedData_afterDelete })
  }

  deleteParticularScannedGames(storedData){
    this.setState({storedData: storedData})
  }

  navigateToProductPage = game_id => {
    productLink(game_id)
      .then(async (response) => {
        if (response.status == 200) {
          // store before saving
          console.log("[Product] Data",response.data)
          this.storeArray(response.data)
        }      
      })
      .catch(error => {
        console.log("Product link error new", error.message);
      });
  };

  handleBarCodeScanned = ({ type, data }) => {
    this.setState({ 
        scanned: true,
        scanCount: this.state.scanCount + 1 

    });
    this.FetchIsbn(data);
  };

  FetchIsbn(data) {
     if(data[0] == '0' && Platform.OS === "ios"){
          data = data.slice(1,data.length)
        }
    FetchIsbn(data)
      .then(response => {
        console.log("ISBN GET DATA", response.data);
        this.setState(
          {
            game_id: response.data.id
          },
          () => {
            this.navigateToProductPage(this.state.game_id);
          });
      })
      .catch(error => {
        console.log("[error] Game", error.message);
      });
  }
  render() {
    const { height, width } = Dimensions.get('window');
    const maskRowHeight = (height - 100) / 20;
    const maskColWidth = (width - 250) / 2;
     const { hasCameraPermission, scanned } = this.state;

    if (hasCameraPermission === null) {
      return <Text>Requesting for camera permission</Text>;
    }
    if (hasCameraPermission === false) {
      return <Text>No access to camera</Text>;
    }
    return (
      <View style={styles.welcomeView}>


        <View style={styles.icons}>
            <Text style={[styles.image1Image,{color:"#fff",fontSize:20}]}>Scan: { this.state.storedData.length }</Text>
            <TouchableOpacity onPress = {() => {this.props.navigation.navigate("MultipleScanGame", {storedData: this.state.storedData, AfterDeleteUpdate: this.AfterDeleteUpdate, deleteParticularScannedGames: this.deleteParticularScannedGames})}}>

              <AntDesign
                name="closecircleo"
                size={25}
                color={"white"}
                style={styles.image2Image}
              />
            </TouchableOpacity>
        </View>
         <View style={styles.lableView}>
            <Text
              style={styles.labelText}>
              {`Move your device slowly until the code gets \ninto focus`}</Text>
          </View>
        <View
          style={{
            //flex: 1,
            flexDirection: 'column',
            justifyContent: 'flex-end',
          }}>
            <BarCodeScanner
              onBarCodeScanned={this.handleBarCodeScanned}
              style={styles.video_scanner}>
              <View style={styles.maskOutter}>
                <View style={[{ flex: 15 }, styles.maskRow, styles.maskFrame]} />
                 <View style={[{ flex: 20 }, styles.maskCenter]}>
                   <View style={[{ width: maskColWidth }, styles.maskFrame]} />
                   <View style={styles.maskInner} />
                  <View style={[{ width: maskColWidth }, styles.maskFrame]} />
                </View>
                 <View style={[{ flex: maskRowHeight }, styles.maskRow, styles.maskFrame]} />
              </View>
            </BarCodeScanner>    
        </View>
      </View>
    );
  }
}
