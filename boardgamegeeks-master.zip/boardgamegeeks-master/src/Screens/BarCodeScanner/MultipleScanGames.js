import {
  Image,
  Text,
  View,
  Platform,
  TouchableOpacity,
  TouchableHighlight,
  ScrollView,
  AsyncStorage,
  Alert
} from "react-native";
import React from "react";
import styles from "../../Styles/BarCodeScannerStyles/MultipleScanGamesStyleSheet";
import { productLink } from "../../Networks/DiscoveryCalls";
import { LinearGradient } from "expo-linear-gradient";
import { AntDesign, MaterialIcons, EvilIcons,Entypo, Ionicons } from "@expo/vector-icons";
import Menu, { MenuItem, MenuDivider } from 'react-native-material-menu';
import {AddCollectionGame, FetchCollectionGameStatus,} from '../../Networks/ProductPageCalls';
import Toast from 'react-native-root-toast';
import { MyGameCollection, deleteGameFromCollection } from "../../Networks/MyCollectionCalls";


export default class MultipleScanGames extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      storedData: this.props.navigation.state.params.storedData,
      isClicked:false,
      game_id:"",
      pressStatus:false,
      _menu:null,
      visible: false,
      notVisible : false,
      add_to_collection: false
    };
 
    this.deleteGameAlert = this.deleteGameAlert.bind(this);
    this.renderDeleteGameFromCollection = this.renderDeleteGameFromCollection.bind(this);
    this.historyContent = this.historyContent.bind(this);
    this.navigateToProductPage = this.navigateToProductPage.bind(this);
   this.gettingGameCollectionStatus = this.gettingGameCollectionStatus.bind(this);
    this.addAll=this.addAll.bind(this);
   
  }


//add to collection 
renderAddCollectionGame() {
  let gameId = this.props.gameId.toString() 
 if (this.props.navigation_from == "WelcomePage") {
   this.props.setModalVisible(true);
 } else {
   AddCollectionGame(gameId)
     .then(response => {
       if (response.status == 200) {
       setTimeout(() => this.setState({
           visible: true
       }), 50);     
       setTimeout(() => this.setState({
           visible: false
       }), 800);
         MyGameCollection(this.onSuccess,this.onFailure)
         this.setState({ 
           add_to_collection: true
         });
       }
     })
     .catch(error => {
       console.log("@Error [GameMainHeader] AddToCollection", error.message);
     });
 }
 this.hideMenu();
}


  addAll(){
    console.log("addAll clicked ")
    let stored = this.state.storedData;
   let games_ids =[]
  stored.map(game => {
    games_ids.push(game.game)
  }) 
    let games_ids_string =games_ids.toString();
    AddCollectionGame(games_ids_string).then((response) =>{
      console.log(response.data)   
      setTimeout(() => this.setState({
              visible: true
          }), 50);     
          setTimeout(() => this.setState({
              visible: false
          }), 800);  
    })
    
    }
    gettingGameCollectionStatus() {
      let stored = this.state.storedData;
   let games_ids =[]
  stored.map(game => {
    games_ids.push(game.game)
  }) 
    let games_ids_string =games_ids.toString();
    FetchCollectionGameStatus(games_ids_string)
    .then(response => {
      console.log("response data is",response.data)
      
      })
      .catch(error => {
        console.log("error of FetchCollectionGameStatus", error.message);
      });
    }
  async componentDidMount() {
    
 
    const storedData = this.props.navigation.state.params.storedData.length == 0 ?
    await AsyncStorage.removeItem('ScanHistoryJS') : 
      JSON.parse(await AsyncStorage.getItem('ScanHistoryJS'));
   
    
     if (storedData) {
      this.setState({ storedData: storedData })
    }

  
  }


  deleteGameAlert(game_id) {
    Alert.alert(
      "Do you want to Delete",
      "This will remove this item from your collection",
      [
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel"
        },
        {
          text: "Delete",
          onPress: () => this.renderDeleteGameFromCollection(game_id)
        }
      ]
    );
  }

    async renderDeleteGameFromCollection(game_id) {
      let storedData;
      try {
        storedData = JSON.parse(await AsyncStorage.getItem('ScanHistoryJS'))
        console.log("stored data is",storedData)
        for(i=0;i<storedData.length;i++){
          if(game_id==storedData[i].id){
            storedData.splice(i, 1); 
          }
        }      
      } catch(error) {
        console.log('[Scan] Storage Error')
      }
     this.setState({ storedData: storedData })
    this.props.navigation.state.params.AfterDeleteUpdate(this.state.storedData);
      await AsyncStorage.setItem('ScanHistoryJS', JSON.stringify(storedData))
      }
    navigateToProductPage(game_id) {
      productLink(game_id)
        .then(response => {
          if (response.status == 200) {
            this.props.navigation.navigate("GameInfo", {
              productData: response.data,
              game_id: game_id
            });
          }
        })
        .catch(error => {
          console.log("error", error.message);
        });
    }
  historyContent(items, index) {
    let card_image =
        items.card_image && items.card_image.length
          ? { uri: items.card_image[0] }
          : require("../../../assets/Image/ABCme.jpeg");

    return (
      <View>
        <TouchableOpacity
        onPress={() => {
          this.navigateToProductPage(items.game);
        }}>
          <View style={{ flex: 1, flexDirection: "row" }}>
            <View style={styles.GameImage}>
              <Image source={card_image} style={styles.imageViewContainer} />
            </View>
            <View style={styles.textViewContainer}>
              <Text>
                {items.name}
                <Text style={{ color: "#rgba(204, 202, 208, 0.95)" }}>
                  {" "}
                  ({items.year_published})
                </Text>
              </Text>
              <Text style={{ marginTop: 2 }}>
                {items.minimum_players}-{items.maximum_players} Players
              </Text>
            </View>

            <View style={styles.DltImage}>
              {/* delete icon */}
              <TouchableHighlight
                onPress={() => {
                  this.deleteGameAlert(items.id);
                }}
                underlayColor="rgba(0,0,0,0.08)"
                style={{ 
                  padding: 15,
                  borderRadius: 25,
                  backgroundColor: "white",
                }}
              >
                <Image
                  source={require("../../../assets/Image/delet.png")}
                  style={styles.imageViewDlt}
                />
              </TouchableHighlight>
            

            </View>
            </View>
         
        </TouchableOpacity>
        <View style={styles.separatorView1} />
      </View>
    );
  }

  render() {
    return (
      <View style={{ flex: 1}}>
        {this.state.storedData &&
          this.state.storedData.length > 0 ? (
            <ScrollView showsVerticalScrollIndicator={false}> 
            {this.state.storedData.map(this.historyContent)}
            </ScrollView>
          ) : (
            <View style={styles.ImageView}>
              <Image
                source={require("../../../assets/Image/no_game_scanned.png")}
                style={styles.imageImage}
              />
              <Text style={styles.labelText}> No games scanned yet</Text>
            </View>
          )}
        {/* end  you should write like this*/} 

        <View style={{ width: '100%', bottom:0,position:'absolute'}}>
        <View style={styles.separatorView} />
          <View style ={{flexDirection:'row', justifyContent:"space-evenly",alignItems:"flex-end"}}>
          {/* <View style ={{}}> */}
            {/* <View style={[styles.deleteButton, {marginBottom:8}]}> 
              <TouchableOpacity onPress={this.deleteAll}>
                <Text style={styles.deleteButtonText}>Delete all</Text>
              </TouchableOpacity>
              </View> */}
             <View style ={styles.addToCollection}>
              <TouchableOpacity onPress={this.addAll}>
                <Text style={styles.addButtonText}>Add to collection</Text>
              </TouchableOpacity>
            {/* </View> */}
            <Toast
              visible={this.state.visible}
              position={-120}
              shadow={false}
              animation={false}
              hideOnPress={true}
            >Successfully Collected All</Toast>

            <Toast
              visible={this.state.notVisible}
              position={-120}
              shadow={false}
              animation={false}
              hideOnPress={true}
            >You have already Collected</Toast>
            </View>
            <View style={styles.scanButton} >
              <TouchableOpacity onPress={() => { this.props.navigation.navigate("MultipleScanner",{storedData:this.state.storedData}) }}>
                <Text style={styles.scanButtonText}>Scan More</Text>
              </TouchableOpacity>
            </View>            
          </View>
        </View>
      </View>
    );
  }
}

/*
      It will be used in future.
      <TouchableOpacity style={styles.addcollectionButton}>
        <Text style={styles.addcollectionButtonText}>
          Add to collection all
           </Text>
      </TouchableOpacity>
*/
