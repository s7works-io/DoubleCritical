import React from "react";
import Image from "react-native-remote-svg";
import {
  createBottomTabNavigator,
  createStackNavigator
} from "react-navigation";
import { NavigationScanOptions } from "../Components/NavigationScanOption.js"
import BarCodeGame from '../Screens/BarCodeScanner/BarCodeGame.js'
import Scan from '../Screens/BarCodeScanner/Scan.js'
import MultipleScanGame from '../Screens/BarCodeScanner/MultipleScanGames.js'
import ScanHistory from '../Screens/BarCodeScanner/ScanHistory.js'
import MultipleScanner from '../Screens/BarCodeScanner/MultipleScanner.js'
import ScanImage from "../../assets/Image/ScanImage.svg";
import MultipleScanImage from "../../assets/Image/ScanImage.svg";
import HistoryImage from "../../assets/Image/ugcfeed.png";

const ScanIcon = () => <ScanImage width={25} height={25} />;
const MultipleIcon = () => <MultipleScanImage width={25} height={25} />;
const HistoryIcon = () => <Image source={HistoryImage} style={{ marginTop: 5, tintColor: "grey" }} />;

const bottomTabIcon = (options, TabImage) => {
  const { focused, tintColor } = options;
  return <TabImage />;
};

export const MultipleScanStack = createStackNavigator({
    MultipleScanner: {
        screen: MultipleScanner,
        //navigationOptions: (options) => NavigationScanOptions(options, "Multiple scan games")
      },
    });

export const scanHistoryStack = createStackNavigator({
  ScanHistory: {
      screen: ScanHistory,
     // navigationOptions: (options) => NavigationScanOptions(options, "Scan History")
  },
  });
export const ScanStack = createStackNavigator({
  Scan : {
      screen: Scan,
      //navigationOptions: (options) => NavigationScanOptions(options, "Scan")
  },
  });

export const ScannerTab = createBottomTabNavigator(
  {
    // Bottom tab navigation screens
    Scan: {
      screen: ScanStack,
      navigationOptions: {
        tabBarIcon: options => bottomTabIcon(options, ScanIcon)
      }
    },
    "Multiple Scan": {
      screen: MultipleScanStack,
      navigationOptions: {
        tabBarIcon: options => bottomTabIcon(options, MultipleIcon),
      }
    },
    "History": {
      screen: scanHistoryStack,
      navigationOptions: {
        tabBarIcon: options => bottomTabIcon(options, HistoryIcon)
      }
    }, 
    // BarCodeGame: { 
    //   screen: BarCodeGame,
    //   tabBarOptions: {
    //     visible: false
    //   },
    //  },   
  },
  {
    tabBarOptions: {
      activeTintColor: "#159CDA",
      inactiveTintColor: "black",
      labelStyle: {
        fontSize: 12
      },
      style: {}
    },
    initialRouteName: "Scan",
    defaultNavigationOptions: ({ navigation }) => ({
      tabBarOnPress: ({ navigation, defaultHandler }) => {
        defaultHandler();
      }
    })
  }
);